This folder contains the EVE emulator library. BT8XXEmu library is for graphics and mx25lemu library  is for flash interface.

It supports all the chips of EVE series: from FT80X to BT81X. 


